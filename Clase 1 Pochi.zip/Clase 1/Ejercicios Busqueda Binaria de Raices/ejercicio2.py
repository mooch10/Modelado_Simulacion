import numpy as np
import matplotlib.pyplot as plt
from tabulate import tabulate
import sympy as sp

def bisection_method(f_sym, a, b, tol=1e-5, max_iter=100):
    x = sp.symbols('x')
    f = sp.lambdify(x, f_sym, 'numpy')
    
    fa = f(a)
    fb = f(b)
    
    # Validación 1: ¿La raíz está exactamente en uno de los bordes?
    if fa == 0:
        return a, [[0, a, b, a, fa, 0]]
    if fb == 0:
        return b, [[0, a, b, b, fb, 0]]
        
    # Validación 2: ¿Hay cambio de signo?
    if fa * fb > 0:
        raise ValueError(f"No hay cambio de signo garantizado en el intervalo [{a}, {b}].")
        
    iterations = []
    for i in range(max_iter):
        c = (a + b) / 2
        fc = f(c)
        error = abs(b - a) / 2
        
        iterations.append([
            i + 1, 
            round(a, 5), 
            round(b, 5), 
            round(c, 5), 
            round(fc, 5), 
            round(error, 5)
        ])
        
        # Criterio de detención
        if error < tol or fc == 0:
            return c, iterations
            
        # Reasignación de límites
        if fa * fc < 0:
            b = c
            fb = fc
        else:
            a = c
            fa = fc
            
    return c, iterations

def main():
    x = sp.symbols('x')
    
    # f(x) = 3(x + 1)(x - 1/2)(x - 1)
    f_sym = 3 * (x + 1) * (x - 0.5) * (x - 1)
    
    intervalos = [(-1.0, 1.5), (-1.25, 2.5)]
    
    # Preparamos el canvas para los gráficos
    fig, axs = plt.subplots(1, 2, figsize=(14, 5))
    
    for idx, (a, b) in enumerate(intervalos):
        print(f"\n--- Búsqueda Binaria en el intervalo [{a}, {b}] ---")
        try:
            raiz, iteraciones = bisection_method(f_sym, a, b)
            print(tabulate(
                iteraciones,
                headers=["Iteración", "a", "b", "c (medio)", "f(c)", "Error"],
                tablefmt="grid"
            ))
            print(f"Raíz encontrada o límite alcanzado: {raiz:.5f}")
            
            # Gráfico
            ax = axs[idx]
            x_vals = np.linspace(a - 0.5, b + 0.5, 400)
            f_func = sp.lambdify(x, f_sym, 'numpy')
            y_vals = f_func(x_vals)
            
            ax.plot(x_vals, y_vals, label='$f(x)$')
            ax.axhline(0, color='black', linewidth=0.8)
            ax.axvline(0, color='black', linewidth=0.8)
            ax.grid(color='gray', linestyle='--', linewidth=0.5)
            ax.axvspan(a, b, color='orange', alpha=0.2, label=f'Intervalo [{a}, {b}]')
            ax.plot(raiz, f_func(raiz), 'ro', label=f'Raíz encontrada: {raiz:.4f}')
            
            ax.set_title(f'Intervalo [{a}, {b}]')
            ax.set_xlabel('$x$')
            ax.set_ylabel('$f(x)$')
            ax.legend()
            
        except ValueError as e:
            print(e)

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()