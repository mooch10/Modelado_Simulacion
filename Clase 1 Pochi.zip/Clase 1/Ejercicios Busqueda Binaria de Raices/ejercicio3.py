import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
from tabulate import tabulate
import warnings

def bisection_method(f_sym, a, b, tol=1e-3, max_iter=100):
    x = sp.symbols('x')
    f = sp.lambdify(x, f_sym, 'numpy')
    
    fa = f(a)
    fb = f(b)
    
    iteration_log = []
    
    if fa == 0:
        return a, 0, iteration_log
    if fb == 0:
        return b, 0, iteration_log
        
    if fa * fb > 0:
        raise ValueError(f"No hay cambio de signo garantizado en [{a}, {b}].")
        
    for i in range(max_iter):
        c = (a + b) / 2.0
        fc = f(c)
        error = abs(b - a) / 2.0
        
        # Guardamos el estado actual de la iteración
        iteration_log.append([
            i + 1, 
            round(a, 5), 
            round(b, 5), 
            round(c, 5), 
            round(fc, 5), 
            round(error, 5)
        ])
        
        if error < tol or fc == 0:
            return c, i + 1, iteration_log
            
        if fa * fc < 0:
            b = c
            fb = fc
        else:
            a = c
            fa = fc
            
    return c, max_iter, iteration_log

def main():
    x = sp.symbols('x')
    
    # Definición de los incisos
    ejercicios = [
        ('a', sp.sqrt(x) - sp.cos(x), 0, 1),
        ('b', x - 2**(-x), 0, 1),
        ('c', sp.exp(x) - x**2 + 3*x - 2, 0, 1),
        ('d.1', 2*x*sp.cos(x) - (x + 1)**2, -3, -2),
        ('d.2', 2*x*sp.cos(x) - (x + 1)**2, -1, 0),
        ('e.1', x*sp.cos(x) - 2*x**2 + 3*x - 1, 0.2, 0.3),
        ('e.2', x*sp.cos(x) - 2*x**2 + 3*x - 1, 1.2, 1.3)
    ]
    
    resultados = []
    
    # Preparamos la grilla para los gráficos (4 filas, 2 columnas)
    fig, axs = plt.subplots(4, 2, figsize=(14, 16))
    axs = axs.flatten()
    
    for idx, (nombre, f_sym, a, b) in enumerate(ejercicios):
        try:
            raiz, iteraciones, iter_log = bisection_method(f_sym, a, b, tol=1e-3)
            resultados.append([nombre, str(f_sym), f"[{a}, {b}]", round(raiz, 4), iteraciones])
            
            # --- Imprimimos las iteraciones paso a paso en la consola ---
            if iter_log:
                print(f"\n--- Iteraciones Bisección: Inciso {nombre}) f(x) = {f_sym} ---")
                print(tabulate(
                    iter_log,
                    headers=["Iteración", "a", "b", "c (medio)", "f(c)", "Error"],
                    tablefmt="grid"
                ))
            
            # --- Lógica del gráfico ---
            ax = axs[idx]
            margen = (b - a) * 0.5
            x_vals = np.linspace(a - margen, b + margen, 400)
            
            f_func = sp.lambdify(x, f_sym, 'numpy')
            
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                y_vals = f_func(x_vals)
                
            ax.plot(x_vals, y_vals, label=f'$f(x)$')
            ax.axhline(0, color='black', linewidth=0.8)
            ax.axvline(0, color='black', linewidth=0.8)
            ax.grid(color='gray', linestyle='--', linewidth=0.5)
            
            # Sombreamos el intervalo original
            ax.axvspan(a, b, color='orange', alpha=0.2, label=f'Intervalo [{a}, {b}]')
            
            # Marcamos la raíz encontrada
            ax.plot(raiz, f_func(raiz), 'ro', label=f'Raíz c = {raiz:.4f}')
            
            ax.set_title(f'Inciso {nombre}')
            ax.set_xlabel('x')
            ax.set_ylabel('f(x)')
            ax.legend()
            
        except ValueError as e:
            resultados.append([nombre, str(f_sym), f"[{a}, {b}]", "Error", str(e)])

    # Ocultamos el último gráfico (el octavo) que queda vacío porque son 7 incisos
    axs[-1].axis('off')

    print("\n=== RESULTADOS FINALES: EJERCICIO 3 (Tolerancia 10^-3) ===")
    print(tabulate(
        resultados,
        headers=["Inciso", "Función f(x)", "Intervalo [a, b]", "Raíz (c)", "Iteraciones"],
        tablefmt="grid"
    ))
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()