import numpy as np
import matplotlib.pyplot as plt
from tabulate import tabulate
import sympy as sp
import warnings

def fixed_point(initial_value, f_sym, g_sym, ax, plot_range, max_iterations=100, tolerance=1e-6, precision=5):
    x_sym = sp.symbols('x')
    g = sp.lambdify(x_sym, g_sym, 'numpy')
    f = sp.lambdify(x_sym, f_sym, 'numpy')
    h = 1e-5
    
    # Omitimos warnings matemáticos que numpy maneja internamente
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        deriv = (g(initial_value + h) - g(initial_value - h)) / (2 * h)
        
    if abs(deriv) >= 1:
        raise ValueError(f"No cumple la condición de convergencia (|g'(x0)| = {abs(deriv):.4f} >= 1)")

    x = initial_value
    iterations = []
    
    for i in range(max_iterations):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            x_new = g(x)
            
        abs_error = abs(x_new - x)
        rel_error = abs((x_new - x) * 100 / x_new) if x_new != 0 else float('inf')
        
        iterations.append([
            i + 1,
            round(x, precision),
            round(x_new, precision),
            round(abs_error, precision),
            f"{round(rel_error, 2)} %"
        ])
        
        if abs_error < tolerance:
            # Armamos el gráfico en el 'ax' correspondiente de la grilla
            x_vals = np.linspace(plot_range[0], plot_range[1], 400)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                y_vals = f(x_vals)
                
            ax.plot(x_vals, y_vals, label=f'$f(x)$')
            ax.plot(x_new, f(x_new), 'ro', label=f'Raíz c ≈ {x_new:.5f}')
            ax.axhline(0, color='black', linewidth=0.5)
            ax.axvline(0, color='black', linewidth=0.5)
            ax.grid(color='gray', linestyle='--', linewidth=0.5)
            ax.set_xlabel('$x$')
            ax.set_ylabel('$f(x)$')
            ax.legend()
            
            return x_new, iterations
            
        x = x_new
        
    raise ValueError("El método no convergió dentro del número máximo de iteraciones.")

def main():
    x = sp.symbols('x')
    
    # Definimos los 5 ejercicios: (id, f(x), g(x), x0, rango_para_graficar)
    ejercicios = [
        ('1', 2 * sp.exp(x**2) - 5 * x, (2 * sp.exp(x**2)) / 5, 0.0, (0, 1)),
        ('2', sp.cos(x), x + sp.cos(x), 1.0, (1, 2)),
        # Ajustamos x0 a 0.5 en el ejercicio 3 para evitar que salte el ValueError
        ('3', sp.exp(-x) - x, sp.exp(-x), 0.5, (0, 1)), 
        ('4', x**3 - x - 1, (x + 1)**(1/3), 1.0, (1, 2)),
        ('5', sp.pi + 0.5 * sp.sin(x/2) - x, sp.pi + 0.5 * sp.sin(x/2), 0.0, (0, 7))
    ]
    
    # Preparamos una grilla de 3x2 para acomodar los 5 gráficos
    fig, axs = plt.subplots(3, 2, figsize=(14, 15))
    axs = axs.flatten()
    
    for idx, (inciso, f_sym, g_sym, x0, p_range) in enumerate(ejercicios):
        print(f"\n--- Ejercicio {inciso} ---")
        print(f"f(x) = {f_sym}")
        print(f"g(x) = {g_sym}")
        print(f"Valor inicial x0 = {x0}")
        
        try:
            # Seteamos la tolerancia estricta
            raiz, iteraciones = fixed_point(x0, f_sym, g_sym, axs[idx], p_range, tolerance=1e-6)
            print(tabulate(
                iteraciones,
                headers=["Iteración", "x", "g(x)", "Error Absoluto", "Error Relativo"],
                tablefmt="grid"
            ))
            print(f"Raíz aproximada: {raiz:.5f}")
            axs[idx].set_title(f'Ejercicio {inciso}')
            
        except ValueError as e:
            print(f"Error: {e}")
            axs[idx].set_title(f'Ejercicio {inciso} - FALLO')
            axs[idx].text(0.5, 0.5, str(e), horizontalalignment='center', verticalalignment='center', transform=axs[idx].transAxes)
            
    # Escondemos el sexto gráfico de la grilla porque queda vacío
    axs[-1].axis('off')
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()