import sympy as sp
import numpy as np
import matplotlib.pyplot as plt

def main():
    x = sp.symbols('x')
    g_sym = 2**(-x)
    
    print("==================================================")
    print(" DEMOSTRACIÓN TEOREMA DEL PUNTO FIJO - EJERCICIO 7")
    print("==================================================\n")
    
    a, b = 1/3, 1
    g_func = sp.lambdify(x, g_sym, 'numpy')
    
    print("Verificando analíticamente por consola...")
    print(f"g(1/3) = {g_func(a):.4f}")
    print(f"g(1)   = {g_func(b):.4f}")
    print("Todo OK. Generando gráfico demostrativo...")
    
    # --- Lógica del Gráfico ---
    x_vals = np.linspace(0, 1.5, 400)
    y_vals = g_func(x_vals)
    
    plt.figure(figsize=(8, 6))
    
    # Graficamos g(x) y la recta identidad y=x
    plt.plot(x_vals, y_vals, 'b-', label='$g(x) = 2^{-x}$')
    plt.plot(x_vals, x_vals, 'g--', label='$y = x$ (Identidad)')
    
    # Dibujamos la "caja" del intervalo compacto [1/3, 1] x [1/3, 1]
    plt.plot([a, b, b, a, a], [a, a, b, b, a], 'orange', linestyle=':', linewidth=2, label='Caja del Intervalo $[1/3, 1]$')
    plt.fill_between([a, b], a, b, color='orange', alpha=0.1)
    
    # SOLUCIÓN DEL ERROR: Usamos sympy (sp.nsolve) en lugar de scipy para buscar la raíz
    # Esto resuelve numéricamente g(x) - x = 0, arrancando desde una estimación inicial de 0.5
    punto_fijo = float(sp.nsolve(g_sym - x, 0.5))
    
    plt.plot(punto_fijo, punto_fijo, 'ro', label=f'Punto Fijo ≈ {punto_fijo:.4f}')
    
    plt.axhline(0, color='black', linewidth=0.8)
    plt.axvline(0, color='black', linewidth=0.8)
    plt.grid(color='gray', linestyle='--', linewidth=0.5)
    
    plt.title('Demostración Visual - Teorema de Banach')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()