import numpy as np
import matplotlib.pyplot as plt
from tabulate import tabulate
import sympy as sp
import warnings

def incremental_search(f_sym, x_start, x_end, step=1, precision=4):
    x_sym = sp.symbols('x')
    # Convertimos la función simbólica a una evaluable con numpy
    f = sp.lambdify(x_sym, f_sym, 'numpy')
    
    # Generamos los valores enteros a evaluar
    x_vals = np.arange(x_start, x_end + step, step)
    intervals = []
    iteration_log = [] # <-- Agregamos esta lista para guardar el paso a paso
    
    # Atrapamos warnings por si evaluamos logaritmos en números negativos o ceros
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for i in range(len(x_vals) - 1):
            a = x_vals[i]
            b = x_vals[i+1]
            fa = f(a)
            fb = f(b)
            
            # Chequeamos que el resultado sea un número válido y no infinito
            if not np.isnan(fa) and not np.isnan(fb) and not np.isinf(fa) and not np.isinf(fb):
                # Guardamos la iteración actual en nuestro log
                iteration_log.append([i + 1, a, b, round(fa, precision), round(fb, precision)])
                
                # Teorema de Bolzano: cambio de signo
                if fa * fb < 0:
                    intervals.append([
                        str(f_sym),
                        f"[{a}, {b}]",
                        round(fa, precision),
                        round(fb, precision),
                        a, b  # Guardamos a y b crudos para usarlos en el gráfico
                    ])
                    
    return intervals, f, iteration_log

def main():
    x = sp.symbols('x')
    
    # Definimos las 4 funciones del ejercicio y sus rangos de búsqueda (inicio, fin)
    funciones = [
        (sp.exp(x) - 2 - x, -5, 5),          # a) f(x) = e^x - 2 - x
        (sp.cos(x) + x, -5, 5),              # b) f(x) = cos(x) + x
        (sp.ln(x) - 5 - x, 0.1, 5),          # c) f(x) = ln(x) - 5 - x (x > 0)
        (x**2 - 10*x + 23, 0, 10)            # d) f(x) = x^2 - 10x + 23
    ]
    
    resultados_tabla = []
    
    # Preparamos una grilla de 2x2 para los gráficos
    fig, axs = plt.subplots(2, 2, figsize=(12, 10))
    axs = axs.flatten()
    
    for idx, (f_sym, x_start, x_end) in enumerate(funciones):
        intervalos, f_lambdified, iteration_log = incremental_search(f_sym, x_start, x_end)
        
        # --- Imprimimos las iteraciones paso a paso en la consola ---
        if iteration_log:
            print(f"\n--- Iteraciones Búsqueda Incremental: Función {chr(97+idx)}) f(x) = {f_sym} ---")
            print(tabulate(
                iteration_log,
                headers=["Iteración", "a", "b", "f(a)", "f(b)"],
                tablefmt="grid"
            ))
        
        # Guardamos los primeros 4 elementos para la tabla final que va a la consola
        for inter in intervalos:
            resultados_tabla.append(inter[:4])
            
        # --- Lógica de gráficos estilo matplotlib ---
        ax = axs[idx]
        x_plot = np.linspace(x_start, x_end, 400)
        
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            y_plot = f_lambdified(x_plot)
            
        ax.plot(x_plot, y_plot, label=f'$f(x) = {str(f_sym)}$')
        ax.axhline(0, color='black', linewidth=0.8)
        ax.axvline(0, color='black', linewidth=0.8)
        ax.grid(color='gray', linestyle='--', linewidth=0.5)
        
        # Sombreamos el intervalo encontrado y marcamos los puntos
        for inter in intervalos:
            a, b = inter[4], inter[5]
            ax.axvspan(a, b, color='orange', alpha=0.3, label=f'Intervalo [{a}, {b}]')
            ax.plot([a, b], [f_lambdified(a), f_lambdified(b)], 'ro')
            
        ax.set_title(f'Función {chr(97+idx)})')
        ax.set_xlabel('$x$')
        ax.set_ylabel('$f(x)$')
        ax.legend()

    # Imprimimos la tabla final resumen
    print("\n=== RESULTADOS FINALES: INTERVALOS ENCONTRADOS ===")
    print(tabulate(
        resultados_tabla,
        headers=["Función", "Intervalo [a, b]", "f(a)", "f(b)"],
        tablefmt="grid"
    ))
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()