import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
from tabulate import tabulate

def fixed_point_iteration(g_sym, x0, tol=1e-3, max_iter=100):
    x = sp.symbols('x')
    g = sp.lambdify(x, g_sym, 'numpy')
    
    x_curr = x0
    iterations = []
    # Guardamos los puntos para hacer la "escalerita" del gráfico
    puntos_grafico = [(x0, 0), (x0, g(x0))] 
    
    for i in range(max_iter):
        x_new = g(x_curr)
        error = abs(x_new - x_curr)
        
        iterations.append([i + 1, round(x_curr, 5), round(x_new, 5), round(error, 5)])
        puntos_grafico.append((x_new, x_new))
        puntos_grafico.append((x_new, g(x_new)))
        
        if error <= tol:
            return x_new, iterations, puntos_grafico
            
        x_curr = x_new
        
    return x_curr, iterations, puntos_grafico

def main():
    x = sp.symbols('x')
    g_sym = 5 / (x**2) + 2
    
    print("==================================================")
    print(" EJERCICIO 9 - MÉTODO DEL PUNTO FIJO")
    print("==================================================\n")
    print(f"Función iterativa: g(x) = {g_sym}")
    print("Intervalo de convergencia seguro: [2.2, 3]")
    
    x0 = 2.5 # Valor inicial dentro de la zona de convergencia
    
    raiz, iteraciones, puntos_grafico = fixed_point_iteration(g_sym, x0, tol=1e-3)
    
    print(f"\nArrancando desde x0 = {x0}:")
    print(tabulate(iteraciones, headers=["Iteración", "x_n", "g(x_n)", "Error Abs."], tablefmt="grid"))
    print(f"\nPunto fijo alcanzado: {raiz:.5f}")
    
    # --- Gráfico ---
    x_vals = np.linspace(2.1, 3.2, 400)
    g_func = sp.lambdify(x, g_sym, 'numpy')
    y_vals = g_func(x_vals)
    
    plt.figure(figsize=(8, 6))
    plt.plot(x_vals, y_vals, 'b-', label='$g(x) = 5/x^2 + 2$')
    plt.plot(x_vals, x_vals, 'g--', label='$y = x$')
    
    px, py = zip(*puntos_grafico)
    plt.plot(px, py, 'r:', linewidth=1.5, label='Iteraciones')
    plt.plot(raiz, raiz, 'ro', label=f'Punto Fijo ≈ {raiz:.4f}')
    
    plt.title('Ejercicio 9 - Convergencia del Punto Fijo')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.grid(color='gray', linestyle='--', linewidth=0.5)
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()