import sympy as sp

def main():
    # Definimos el símbolo 'p' (nuestro punto fijo)
    p = sp.symbols('p')
    
    # Definimos la función original f(p) que queremos alcanzar
    f_p = p**4 + 2*p**2 - p - 3
    
    print("==================================================")
    print(" COMPROBACIÓN ALGEBRAICA - MÉTODO DEL PUNTO FIJO")
    print("==================================================\n")
    print(f"Función original objetivo: f(p) = {f_p} = 0\n")
    
    # ---------------------------------------------------------
    # INCISO A
    # ---------------------------------------------------------
    print("-" * 50)
    print("DEMOSTRACIÓN INCISO A:")
    print("Función iterativa: g(p) = (3 + p - 2*p**2)**(1/4)")
    print("Paso 1: Asumimos que 'p' es punto fijo -> p = g(p)")
    
    # En sympy, simulamos el despeje algebraico: 
    # Para eliminar la raíz cuarta, elevamos a la 4ta potencia ambos lados
    print("Paso 2: Elevamos a la 4ta potencia -> p**4 = 3 + p - 2*p**2")
    lado_izquierdo_a = p**4
    lado_derecho_a = 3 + p - 2*p**2
    
    # Paso 3: Pasamos todos los términos al lado izquierdo (restando el lado derecho)
    # y usamos sp.expand() para ordenar el polinomio resultante
    f_obtenida_a = sp.expand(lado_izquierdo_a - lado_derecho_a)
    print(f"Paso 3: Agrupamos e igualamos a cero -> {f_obtenida_a} = 0")
    
    # Verificamos matemáticamente si la función obtenida es equivalente a f(p)
    es_igual_a = sp.simplify(f_obtenida_a - f_p) == 0
    print(f"¿El despeje coincide exactamente con f(p)? {'✅ SÍ' if es_igual_a else '❌ NO'}")
    
    # ---------------------------------------------------------
    # INCISO B
    # ---------------------------------------------------------
    print("\n" + "-" * 50)
    print("DEMOSTRACIÓN INCISO B:")
    print("Función iterativa: g(p) = ((p + 3 - p**4) / 2)**(1/2)")
    print("Paso 1: Asumimos que 'p' es punto fijo -> p = g(p)")
    
    # Simulamos el despeje algebraico: 
    # Elevamos al cuadrado para sacar la raíz y multiplicamos por 2 para sacar el divisor
    print("Paso 2: Elevamos al cuadrado -> p**2 = (p + 3 - p**4) / 2")
    print("Paso 3: Multiplicamos por 2  -> 2*p**2 = p + 3 - p**4")
    lado_izquierdo_b = 2 * p**2
    lado_derecho_b = p + 3 - p**4
    
    # Paso 4: Pasamos todo al lado izquierdo y expandimos
    f_obtenida_b = sp.expand(lado_izquierdo_b - lado_derecho_b)
    print(f"Paso 4: Agrupamos e igualamos a cero -> {f_obtenida_b} = 0")
    
    # Verificamos matemáticamente
    es_igual_b = sp.simplify(f_obtenida_b - f_p) == 0
    print(f"¿El despeje coincide exactamente con f(p)? {'✅ SÍ' if es_igual_b else '❌ NO'}")
    print("-" * 50)

if __name__ == "__main__":
    main()