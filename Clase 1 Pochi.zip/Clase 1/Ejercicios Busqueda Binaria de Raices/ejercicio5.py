import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
from tabulate import tabulate
import warnings

def bisection_method(f_sym, a, b, tol=1e-3, max_iter=100):
    x = sp.symbols('x')
    f = sp.lambdify(x, f_sym, 'numpy')
    
    fa = f(a)
    fb = f(b)
    
    iteration_log = []
    
    if fa == 0:
        return a, 0, iteration_log
    if fb == 0:
        return b, 0, iteration_log
        
    # Validación crucial del Teorema de Bolzano
    if fa * fb > 0:
        raise ValueError(f"Falla Bolzano: f({a})={fa:.2f} y f({b})={fb:.2f} tienen el mismo signo.")
        
    for i in range(max_iter):
        c = (a + b) / 2.0
        fc = f(c)
        error = abs(b - a) / 2.0
        
        # Guardamos el estado actual de la iteración
        iteration_log.append([
            i + 1, 
            round(a, 5), 
            round(b, 5), 
            round(c, 5), 
            round(fc, 5), 
            round(error, 5)
        ])
        
        if error <= tol or fc == 0:
            return c, i + 1, iteration_log
            
        if fa * fc < 0:
            b = c
            fb = fc
        else:
            a = c
            fa = fc
            
    return c, max_iter, iteration_log

def main():
    x = sp.symbols('x')
    
    # Polinomio del ejercicio 5
    f_sym = (x + 2) * (x + 1) * (x - 1)**3 * (x - 2)
    
    # Los 4 intervalos a evaluar
    ejercicios = [
        ('a', -3, 2.5),
        ('b', -2.5, 3),
        ('c', -1.75, 1.5),
        ('d', -1.5, 1.75)
    ]
    
    resultados = []
    
    # Grilla de 2x2 para los gráficos
    fig, axs = plt.subplots(2, 2, figsize=(14, 10))
    axs = axs.flatten()
    
    for idx, (inciso, a, b) in enumerate(ejercicios):
        try:
            raiz, iteraciones, iter_log = bisection_method(f_sym, a, b, tol=1e-3)
            resultados.append([inciso, f"[{a}, {b}]", round(raiz, 5), iteraciones])
            
            # --- Imprimimos las iteraciones paso a paso en la consola ---
            if iter_log:
                print(f"\n--- Iteraciones Bisección: Inciso {inciso}) ---")
                print(tabulate(
                    iter_log,
                    headers=["Iteración", "a", "b", "c (medio)", "f(c)", "Error"],
                    tablefmt="grid"
                ))
                
            # --- Lógica del gráfico para el caso exitoso ---
            ax = axs[idx]
            margen = (b - a) * 0.2
            x_vals = np.linspace(a - margen, b + margen, 400)
            f_func = sp.lambdify(x, f_sym, 'numpy')
            
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                y_vals = f_func(x_vals)
                
            ax.plot(x_vals, y_vals, label='$f(x)$')
            ax.axhline(0, color='black', linewidth=0.8)
            ax.axvline(0, color='black', linewidth=0.8)
            ax.grid(color='gray', linestyle='--', linewidth=0.5)
            ax.axvspan(a, b, color='orange', alpha=0.2, label=f'Intervalo [{a}, {b}]')
            ax.plot(raiz, f_func(raiz), 'ro', label=f'Raíz c ≈ {raiz:.4f}')
            
            ax.set_title(f'Inciso {inciso}) - Convergencia Exitosa')
            ax.set_xlabel('x')
            ax.set_ylabel('f(x)')
            ax.legend()
            
        except ValueError as e:
            # Capturamos el error si no hay cambio de signo y lo graficamos distinto
            resultados.append([inciso, f"[{a}, {b}]", "No converge", str(e)])
            
            ax = axs[idx]
            margen = (b - a) * 0.2
            x_vals = np.linspace(a - margen, b + margen, 400)
            f_func = sp.lambdify(x, f_sym, 'numpy')
            y_vals = f_func(x_vals)
            
            ax.plot(x_vals, y_vals, color='red', label='$f(x)$')
            ax.axhline(0, color='black', linewidth=0.8)
            ax.axvline(0, color='black', linewidth=0.8)
            ax.grid(color='gray', linestyle='--', linewidth=0.5)
            ax.axvspan(a, b, color='gray', alpha=0.2, label=f'Intervalo [{a}, {b}] (Inválido)')
            
            ax.set_title(f'Inciso {inciso}) - Fallo Teórico')
            ax.set_xlabel('x')
            ax.set_ylabel('f(x)')
            ax.legend()

    print("\n=== RESULTADOS FINALES: EJERCICIO 5 (Tolerancia 10^-3) ===")
    print(tabulate(
        resultados,
        headers=["Inciso", "Intervalo [a, b]", "Raíz Aproximada (c)", "Estado / Iteraciones"],
        tablefmt="grid"
    ))
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()