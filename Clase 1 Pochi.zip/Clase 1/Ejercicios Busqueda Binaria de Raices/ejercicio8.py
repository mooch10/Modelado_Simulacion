import numpy as np
import sympy as sp
import matplotlib.pyplot as plt
from tabulate import tabulate

def fixed_point_sqrt(g_sym, x0, tol=1e-4, max_iter=100):
    x_sym = sp.symbols('x')
    g = sp.lambdify(x_sym, g_sym, 'numpy')
    
    x = x0
    iterations = []
    puntos_grafico = [(x0, 0), (x0, g(x0))] # Para graficar los "saltos"
    
    for i in range(max_iter):
        x_new = g(x)
        error = abs(x_new - x)
        
        iterations.append([i + 1, round(x, 6), round(x_new, 6), round(error, 6)])
        puntos_grafico.append((x_new, x_new))
        puntos_grafico.append((x_new, g(x_new)))
        
        if error <= tol:
            return x_new, iterations, puntos_grafico
        
        x = x_new
        
    return x, iterations, puntos_grafico

def main():
    x = sp.symbols('x')
    g_sym = 0.5 * (x + 3/x)
    x0 = 1.5
    
    raiz, iteraciones, puntos_grafico = fixed_point_sqrt(g_sym, x0, tol=1e-4)
    
    print("\nAPROXIMACIÓN DE RAIZ DE 3 - PUNTO FIJO")
    print(tabulate(iteraciones, headers=["Iteración", "x_n", "g(x_n)", "Error Abs."], tablefmt="grid"))
    print(f"\nRaíz aproximada: {raiz:.5f}")
    
    # --- Lógica del Gráfico ---
    x_vals = np.linspace(1.2, 2.0, 400)
    g_func = sp.lambdify(x, g_sym, 'numpy')
    y_vals = g_func(x_vals)
    
    plt.figure(figsize=(8, 6))
    plt.plot(x_vals, y_vals, 'b-', label='$g(x) = 0.5(x + 3/x)$')
    plt.plot(x_vals, x_vals, 'g--', label='$y = x$')
    
    # Dibujamos las iteraciones tipo "escalera"
    px, py = zip(*puntos_grafico)
    plt.plot(px, py, 'r:', linewidth=1.5, label='Iteraciones')
    plt.plot(raiz, raiz, 'ro', label=f'Raíz exacta $\\sqrt{{3}}$ ≈ {raiz:.4f}')
    
    plt.axhline(0, color='black', linewidth=0.8)
    plt.axvline(0, color='black', linewidth=0.8)
    plt.grid(color='gray', linestyle='--', linewidth=0.5)
    
    plt.title('Aproximación de $\\sqrt{3}$ - Método del Punto Fijo')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()